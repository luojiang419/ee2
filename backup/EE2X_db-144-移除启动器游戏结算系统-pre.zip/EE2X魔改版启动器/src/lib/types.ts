export type PageId = "home" | "players" | "updates" | "settings";
export type CloseAction = "exit" | "minimize";

export interface AppConfig {
  gameExe: string;
  gameExePath: string;
  gameDir: string;
  setupCompleted: boolean;
  setupPendingAuth: boolean;
  preferredResolution: string;
  backgroundType: "default" | "image" | "video";
  backgroundImagePath: string;
  backgroundVideoPath: string;
  backgroundBlur: number;
  updateChannel: string;
  closeAction: CloseAction;
  networkServer: string;
  autoConnect: boolean;
  userServerUrl: string;
  updateServerHttp: string;
  updateServerWs: string;
  matchmakingUrl: string;
  battleHotkey: string;
  battleApiUrl: string;
  battleApiKey: string;
  battleApiModel: string;
  battleSubmitUrl: string;
  battleSubmitToken: string;
  battleReportUrl: string;
  battleSshHost: string;
  battleSshPort: number;
  battleSshUsername: string;
  battleSshPassword: string;
  battleSshRemoteDir: string;
}

export interface UserSession {
  username: string;
  avatar: string;
  token: string;
  loginTime: string;
}

export interface RegisterPayload {
  username: string;
  password: string;
  avatar: string;
}

export interface GamePathStatus {
  valid: boolean;
  gameDir: string;
  gameExePath: string;
  markers: string[];
  reason: string;
}

export interface BootstrapState {
  config: AppConfig;
  user: UserSession | null;
  gamePath: GamePathStatus;
  launcherVersion: string;
  gameVersion: string;
  installDir: string;
  defaultBackgroundPath: string;
}

export interface UserProfile {
  id: number;
  username: string;
  avatar: string;
  registerTime: string;
  lastLogin: string;
  isOnline: boolean;
  lastSeen: string;
  totalRuntimeSeconds: number;
  ip: string;
  signature: string;
  combatPower: number;
  rankTier: string;
  rankWins: number;
  partial: boolean;
  notice: string;
}

export interface OnlinePlayer {
  username: string;
  avatar: string;
  combatPower: number;
  rankTier: string;
  wins: number;
  losses: number;
  lastLogin: string;
  lastSeen: string;
  totalRuntimeSeconds: number;
}

export interface NetworkSnapshot {
  connected: boolean;
  status: string;
  mode: string;
  virtualIp: string;
  adapterName: string;
  txTotalBytes: number | null;
  rxTotalBytes: number | null;
  txFallbackBps: number | null;
  rxFallbackBps: number | null;
}

export interface UpdateCheckResult {
  currentLauncherVersion: string;
  currentGameVersion: string;
  latestVersion: string;
  chainVersions: string[];
  hasLauncherUpdate: boolean;
  hasGameUpdate: boolean;
  canUpdate: boolean;
  notes: string[];
}

export interface UpdateRunResult {
  ok: boolean;
  targetVersion: string;
  appliedVersions: string[];
  restartRequired: boolean;
  launcherStageReady: boolean;
  message: string;
  notes: string[];
}

export interface UpdateStatusEvent {
  stage: string;
  message: string;
  progress: number;
  version?: string;
}

export type LauncherInstallerUpdateStatus =
  | "idle"
  | "checking"
  | "downloading"
  | "ready"
  | "installing"
  | "done"
  | "error";

export interface LauncherInstallerUpdateState {
  status: LauncherInstallerUpdateStatus;
  currentVersion: string;
  availableVersion: string;
  notes: string;
  pubDate: string;
  progress: number;
  downloadedBytes: number;
  totalBytes: number | null;
  message: string;
  errorMessage: string;
}

export type BattleRuntimeStatus = "idle" | "running" | "success" | "error";

export interface BattleRuntimeState {
  status: BattleRuntimeStatus;
  message: string;
  shotPath: string;
  csvPath: string;
  submittedAt: string;
  reportUrl: string;
}

export interface BattleCapturePayload {
  shotPath: string;
  imageBase64: string;
}

export interface BattleRunResult {
  ok: boolean;
  message: string;
  shotPath: string;
  csvPath: string;
  submittedAt: string;
  reportUrl: string;
  duplicate: boolean;
  matched: number;
  unmatched: number;
}
